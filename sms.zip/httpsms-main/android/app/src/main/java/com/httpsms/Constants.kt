package com.httpsms

class Constants {
    companion object {
        const val KEY_MESSAGE_ID = "KEY_MESSAGE_ID"
        const val KEY_HEARTBEAT_ID = "KEY_HEARTBEAT_ID"
    }
}
