// @ts-ignore
import VueGlow from 'vue-glow'
import Vue from 'vue'
Vue.component('VueGlow', VueGlow)
