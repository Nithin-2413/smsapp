export interface Heartbeat {
  id: string
  owner: string
  timestamp: string
}
